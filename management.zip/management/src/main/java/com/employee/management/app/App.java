package com.employee.management.app;

public class App {
public static void main(String[] args)
{
	Menu menu =new Menu();
	menu.login();
	menu.mainMenu();
}


}
